package saima3;

import java.util.Calendar;

import javax.swing.JFrame;

import model.User;
public class ImageProcess implements Runnable {
	private User u;
	private ImageDate hdate;         //������ʵ������ͼƬ��
	public double time2;             //���߳����е�ʱ��
	public ImageLoad ld;            
	int j;                           //���ӳ�����б�ǵı���
	double money,tmoney;
	String userName;
	JFrame JF;
	int sum;                          //�û�ѡ���ı�Ǳ���

	ImageProcess(ImageDate hdate,ImageLoad ld,int j,double money,double tmoney,String userName,JFrame JF,int sum){
		this.hdate=hdate;
		this.ld=ld;
		this.j=j;
		this.money=money;
		this.tmoney=tmoney;
		this.userName=userName;
		this.JF=JF;
		this.sum=sum;
	
	
	}
	ImageProcess(ImageDate hdate,int j){
		this.j=j;
		this.hdate=hdate;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		Calendar cal=Calendar.getInstance();
		double x=cal.get(Calendar.SECOND);
		if(j<1){
			for(int i=0;i<250;i++)
			{
				this.hdate.race2();
				try {
					Thread.sleep((int)(Math.random()*200));
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}else{
			for(int i=0;i<230;i++)
			{
				this.hdate.race();
				
				try {
					Thread.sleep((int)(Math.random()*200));
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			Calendar cal2=Calendar.getInstance();
			double y=cal2.get(Calendar.SECOND);
			time2=y-x;
			ld.count2[j-1]=time2;
			if(ld.count2[0]!=0&&ld.count2[1]!=0&&ld.count2[2]!=0&&ld.count2[3]!=0&&hdate.getX()==1150){//���жϵ����ܵ�����
		
				FrameSecond fs=new FrameSecond(money,tmoney,userName,JF,sum,ld.count2); 
				fs.start();
			}
		}
	}

}
