package server;

public interface Protocal {

	int LOGIN=1001;
	int REGISTER=1002;
	int BUY1=1003;
	int BUY2=1004;
	int BUY3=1005;
	int BUY4=1006;
	int BUY5=1007;
	int BUY6=1008;
	int GAMEWIN=1009;
	int GAMELOSE=1010;
	int GAMEDRAW=1011;
	int POINTCHANGE=1012;
	int BET=1013;
	
}
